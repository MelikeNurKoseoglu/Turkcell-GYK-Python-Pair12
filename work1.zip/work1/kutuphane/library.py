from books import Books
class Library:

    def __init__(self):
        self.books = []  # kitapları tutmak için liste

    def kitap_ekle(self, book):
        if any(b.isbn == book.isbn for b in self.books):
            print("Bu kitap zaten kütüphanede mevcut.")
        else:
            self.books.append(book)
            print(f"{book.bookName} kitabı kütüphaneye eklendi.")
      
    def kitap_sil(self, isbn):
        for kitap in self.books:
            if kitap.isbn == isbn:
                self.books.remove(kitap)
                print(f"{kitap.bookName} kitabı kütüphaneden silindi.")
                return
        print("Kitap bulunamadı.")

    def kitapları_goster(self):
        if not self.books:
            print("Kütüphanede kitap bulunmamaktadır.")
        else:
            for kitap in self.books:
                print(kitap)


try:
    library = Library()
    
    print("****")
    kitap1 = Books("Kitap1", "Yazar1", 200, "123456789")
    library.kitap_ekle(kitap1)
    print("****")
    kitap2 = Books("Kitap2", "Yazar2", 150, "987654321")
    library.kitap_ekle(kitap2)
    print("****")
    kitap3 = Books("Kitap1", "Yazar1", 200, "123456789")
    library.kitap_ekle(kitap3) 
    print("****")
    library.kitapları_goster()
    print("****")
    library.kitap_sil("123456789") 
    print("****")
    library.kitap_sil("000000000")
    print("****")
    library.kitapları_goster()

except ValueError as e:
    print(f"Hata: {e}")
except Exception as e:
    print(f"Beklenmeyen bir hata oluştu: {e}")
finally:
    print("Program sonlandırıldı.")
