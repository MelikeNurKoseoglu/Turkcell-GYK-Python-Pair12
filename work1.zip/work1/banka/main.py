class Hesap:

    def __init__(self, name, id, balance):
        self.__balance = balance#Bakiye private
        self.name = name
        self.id = id
    
    def para_yatir(self, miktar):
        self.__balance += miktar
        print(f'{self.name} isimli hesaba {miktar} TL yatırıldı.')

    def para_cek(self, miktar):
        if self.__balance - miktar < 0:
            print('Yetersiz bakiye!')
        else:
            self.__balance -= miktar 
            print(f'{self.name} isimli hesaptan {miktar} TL çekildi.')
            
    def bakiye_goster(self):
        print(f'{self.name} isimli hesabınızda {self.__balance} TL bulunmaktadır.')

class VadesizHesap(Hesap):

    def __init__(self, name, id, balance):
        super().__init__(name, id, balance)  # Miras alınan sınıfın constructor'ını çağırıyoruz

class VadeliHesap(Hesap):
    def __init__(self, name, id, balance):
        super().__init__(name, id, balance)  # Miras alınan sınıfın constructor'ını çağırıyoruz

    def faiz_hesapla(self):
        print('Faiz hesaplandı.')

    def para_cek(self, miktar):
        if self._Hesap__balance - miktar < 0: #hesap sınıfından bakiyeye erişim
            print('Yetersiz bakiye!')
        else:
            self._Hesap__balance -= miktar  
            print(f'{self.name} isimli vadeli hesaptan {miktar} TL çekildi.')


hesap1 = VadeliHesap('Ali', 123, 1000)
hesap1.para_yatir(1000)
hesap1.bakiye_goster()
hesap1.para_cek(2000)
hesap1.bakiye_goster()

print('--------------------------')

hesap2 = VadesizHesap('Veli', 124, 2000)
hesap2.para_yatir(500)
hesap2.bakiye_goster()
hesap2.para_cek(3000)
hesap2.bakiye_goster()
